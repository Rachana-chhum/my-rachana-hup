n=0
sum=0
while n<=15:
  if n % 2 == 0:
   print(n)
  n=n+1