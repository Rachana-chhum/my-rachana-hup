n=0
while n<=15:
    if n%2==1:
        print(n)
    n+=1