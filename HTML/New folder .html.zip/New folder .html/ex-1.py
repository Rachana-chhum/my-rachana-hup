n=0
sum=0
while n<=15:
  sum += n
  n = n + 1
print(sum)